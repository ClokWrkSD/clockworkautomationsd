Clockwork Automation Instagram export (new Clockwork Automation logo, Nov 2, 2026)

12 folders in PUBLISH order: post-01 is tile 12 (posted first), post-12 is tile 1 (posted last). Pin tiles 1 to 3 after the grid is up.
Inside each folder, PNGs are numbered in swipe order (01 = cover). caption.txt holds the caption and hashtags.
All images are 1080 x 1440 (3:4).
Reels (tiles 06 and 10): the PNG is the cover to upload with the recorded video.
Bio link: set to the booking page before posting.
