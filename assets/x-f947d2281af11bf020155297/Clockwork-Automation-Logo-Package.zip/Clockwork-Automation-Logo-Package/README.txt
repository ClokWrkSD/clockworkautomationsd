CLOCKWORK AUTOMATION - LOGO PACKAGE ("Selection")
Built 2026-11-02

THE LOGO
The name is set in monospace type. "clockwork" is plain. "automation" is highlighted like selected text, with a text cursor after it. Type is converted to outlines, so no font install is needed to use any file here.

FILES
svg/            Master vector files. Use these first. stacked/, horizontal/, mark/, on-background/
png/            Same files as PNG with transparent backgrounds (stacked 2400px wide, horizontal 3200px, mark 1200px)
icons/          app-icon (1024, 512, 192, 180), favicon.svg, favicon.ico, favicon PNGs (16, 32, 48, 180)
social/         LinkedIn banner, social share image, Google Business cover, profile avatars (1080, 400)
web/            Website-ready files: header logos (light/dark, tight crop), favicon, apple-touch icon, link-share image
email-signature/ horizontal logo, 300px and 600px (@2x), for light and dark backgrounds
preview-sheet.png  Everything on one page

LAYOUTS
stacked      Default. Use wherever there is room.
horizontal   Headers, email signatures, banners, anywhere height is tight.
mark         "ca" plus cursor. Use for avatars, app icons, stamps. Favicons use a single "c".

VERSIONS
color        Navy text, brass highlight. For cream or white backgrounds.
reversed     Cream text, light brass highlight. For navy or dark backgrounds.
on-gold      White "clockwork", navy block behind "automation" with the letters cut out. For brass backgrounds (#a9741b). Transparent files show the brass through the letters; on-background/ has a ready version on brass.
on-navy      White "clockwork", light brass block behind "automation" with the letters cut out. For navy backgrounds (on-background/ has a ready version).
mono-navy / mono-white / mono-black   One color, highlighted word is cut out of the block. For stamps, engraving, one-color print, and busy backgrounds.

COLORS
Navy          #101a2c
Brass         #a9741b   (use on light backgrounds)
Light brass   #d4a24a   (use on navy only)
Cream         #F7F5F0

TYPE
Logo: DM Mono Medium (SIL Open Font License), converted to outlines.
URL line on social files: DM Mono Regular.

CLEAR SPACE
Keep empty space around the logo equal to the height of the letter "l" in "clockwork". Nothing else sits inside that space.

MINIMUM SIZE
stacked 110px wide (1 in print). horizontal 180px wide (1.5 in print). mark 24px wide. Below that, use the favicon "c".

DO NOT
Recolor outside the versions above. Stretch, rotate, or add shadows. Put color versions on busy photos (use a mono version). Drop the cursor or the highlight.

BEFORE PRINTING
Do not print signage or merchandise until the name checks for "Clockwork" (California bizfile and USPTO trademark search) have cleared.
